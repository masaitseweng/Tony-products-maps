import { Component, ViewChild} from '@angular/core';
import { NavController,NavParams,Slides,AlertController } from 'ionic-angular';
import {NewsletterPage} from '../newsletter/newsletter'; 
import{ProductPage} from '../product/product';
import {FourtwentyProvider} from '../../providers/fourtwenty/fourtwenty'


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {


  category = [{"name":'masa',"images":"../../assets/imgs/420-logo.jpg"},{"name":'testing',"images":"../../assets/imgs/420-logo.jpg"},{"name":"testing","images":"../../assets/imgs/420-logo.jpg"},{"name":'masa',"images":"../../assets/imgs/420-logo.jpg"},{"name":'testing',"images":"../../assets/imgs/420-logo.jpg"},{"name":"testing","images":"../../assets/imgs/420-logo.jpg"}]
  
  product = [{"name":'masa',"images":"../../assets/imgs/420-logo.jpg","quantity":"250","description":"helelejfhf fyffufufb jfufufuf  fuufufuf fufufuf fufuf bfufuf f"},{"name":'masa',"images":"../../assets/imgs/420-logo.jpg","quantity":"250","description":"helelejfhf fyffufufb jfufufuf  fuufufuf fufufuf fufuf bfufuf f"},{"name":'masa',"images":"../../assets/imgs/420-logo.jpg","quantity":"250","description":"helelejfhf fyffufufb jfufufuf  fuufufuf fufufuf fufuf bfufuf f"}]

  @ViewChild('productSlides') productSlides: Slides;

  categories:any

  link:any

  newsltter:any

  // HomeToken : any;

  private token:any ;


     base_url:any= "http://420api.rcmdash.co.za/";

  constructor(public navCtrl: NavController,public provider:FourtwentyProvider,public alertCtrl: AlertController, public navParams: NavParams) {

  
  var to = localStorage.getItem('token')
  console.log("local",to)
   
  
    this.token = navParams.get('token')
    console.log(this.token)

  this.provider.getCategories(this.token).subscribe(data => {
    console.log(data._embedded.categories)

    this.categories = data._embedded.categories
    console.log("link home",this.base_url)
   
  } )


    this.provider.getnewsletter(this.token).subscribe(data =>{

      console.log(data)

      this.newsltter =  data._embedded.posts

    })


    console.log(this.category)

    setInterval(() => {

      if (this.productSlides.getActiveIndex() == this.productSlides.length() - 1)
        this.productSlides.slideTo(0, 2000);

      this.productSlides.slideNext(1000);
    }, 3000);


  }


 openProductPage(product){

  console.log(product._links.products.href)

  this.link = product._links.products.href

  console.log("hello")



  this.provider.getproduct(this.link).subscribe(data =>{
    console.log("inside provider",data._embedded.products)
  
    if(data._embedded.products.length != 0 ){


   //select only product that are available in stock      
      var instock = data._embedded.products.filter(function(item) {
        return item.availability !== "NO";
      });
      
      console.log("gee",instock);



      // tricker an error
      if(instock.length != 0){


        this.navCtrl.push(ProductPage,{
          product:instock
        })
     
      
      }else{

        let alert = this.alertCtrl.create({
          title: 'Error',
          subTitle: 'Out Of Stock',
          buttons: ['Ok']
        });
        alert.present();



      }

    }
    else{


      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: 'This category has no product',
        buttons: ['Ok']
      });
      alert.present();

    }

  })



 }




 openNewsletterPage(product){
   console.log(product)

   this.navCtrl.push(NewsletterPage,{
     product:product
   })
 }

 myCallback(){
   console.log("hello");
 }

}
